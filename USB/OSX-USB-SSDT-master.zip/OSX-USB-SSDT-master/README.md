# Python script for generating an SSDT to inject USB ports (Works on GA-Z170X-UD3)

# Todo:
* ~~Allow all ports~~
* Configure which ports to show in script (For guide creators)
* Do we need to configure HSxx.DPxx and SSxx.DPxx?

# Credit:
Pike R. Alpha: [Using an SSDT to inject USB ports](https://pikeralpha.wordpress.com/2016/07/13/simple-skylake-usb-fix-no-kexts-required/)

RehabMan: [iasl6.1](https://github.com/RehabMan/OS-X-MaciASL-patchmatic)
